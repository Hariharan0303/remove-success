var dragItem = document.getElementsByClassName("shop-item-image");
alert(dragItem);
console.log("dragitem");

/*
var data = [
    { 
        id:"123456",
        title : "DETOX",
        product : [
            {
                id:"123456_prd1",
                title :"THE CLEANING FOAM",
                desc : "Delicate Foam"
            }
        ]
    
    }
    {energize}
    {protect}
];

var html =""
for(stage){
    html +="<h1>"+ (i + 1) + " " + stage[i].title +"</h1>";
    html += "<div>"
    for (product){
        html ="<img class>"
    }
    html +="</div>"
}
*/